import React from "react";
//import './Result.css'

export default function Result(props) {
  const count = props.count;

  return (
    <b>{count}</b>
  )
}